import Link from "next/link";
import { Board } from "@/components/Board";
import { MenuRow } from "@/components/MenuRow";
import { InfoRow } from "@/components/InfoRow";
import { menu } from "@/data/menu";

export default function Beranda() {
  // Ambil 3 menu pertama untuk papan menu andalan
  const featured = menu.slice(0, 3);

  return (
    <>
      <section className="container py-5">
        <div className="row align-items-center g-4 g-lg-5">
          <div className="col-12 col-lg-6">
            <h1 className="hero-title">Ngopi dulu, baru lanjut.</h1>
            <p className="hero-text">
              Kopineko adalah kafe kecil buat ngerjain tugas, ngobrol lama, atau
              sekadar duduk tenang. Kopinya enak, harganya masuk akal.
            </p>
            <div className="d-flex flex-wrap align-items-center gap-3">
              <Link href="/menu" className="btn btn-primary btn-lg">
                Lihat menu
              </Link>
              <Link href="/kontak">Alamat dan jam buka</Link>
            </div>
          </div>

          <div className="col-12 col-lg-6">
            <Board title="Menu andalan">
              {featured.map(function (item) {
                return <MenuRow key={item.id} item={item} />;
              })}
              <p className="mt-3 mb-0">
                <Link href="/menu" className="board-link">
                  Lihat semua menu
                </Link>
              </p>
            </Board>
          </div>
        </div>
      </section>

      <section className="container py-5">
        <div className="row g-4">
          <div className="col-12 col-lg-5">
            <h2 className="section-title">
              Tempat ngopi yang tenang dan tidak bikin kantong tipis.
            </h2>
          </div>
          <div className="col-12 col-lg-7">
            <p>
              Kami buka Kopineko karena capek cari kafe yang bagus tapi
              mahal. Di sini ada colokan di tiap meja, wifi, dan kursi yang
              enak buat duduk berjam-jam.
            </p>
            <Link href="/tentang">Baca cerita kami</Link>
          </div>
        </div>
      </section>

      <section className="band py-5">
        <div className="container">
          <div className="row g-4">
            <div className="col-12 col-lg-5">
              <h2 className="section-title">Mampir ke sini</h2>
            </div>
            <div className="col-12 col-lg-7">
              <dl className="info-list">
                <InfoRow label="Alamat" value="Jl. Kucing Manis No. 8" />
                <InfoRow label="Jam buka" value="Setiap hari, 09.00 sampai 22.00 WIB" />
                <InfoRow label="Instagram" value="@kopineko" />
              </dl>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
