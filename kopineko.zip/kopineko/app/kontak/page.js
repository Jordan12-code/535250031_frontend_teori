import { PageHeader } from "@/components/PageHeader";
import { InfoRow } from "@/components/InfoRow";

export default function Kontak() {
  return (
    <>
      <PageHeader
        title="Kontak"
        text="Mau reservasi atau tanya menu? Datang langsung atau kirim pesan lewat Instagram."
      />

      <section className="container py-5">
        <div className="row">
          <div className="col-12 col-lg-8">
            <dl className="info-list">
              <InfoRow label="Alamat" value="Jl. Kucing Manis No. 8" />
              <InfoRow label="Jam buka" value="Setiap hari, 09.00 sampai 22.00 WIB" />
              <InfoRow label="Instagram" value="@kopineko" />
              <InfoRow
                label="Reservasi"
                value="Kirim DM ke @kopineko. Biasanya dibalas di hari yang sama."
              />
            </dl>
          </div>
        </div>
      </section>
    </>
  );
}
