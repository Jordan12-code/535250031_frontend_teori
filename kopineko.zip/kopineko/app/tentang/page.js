import { PageHeader } from "@/components/PageHeader";
import { InfoRow } from "@/components/InfoRow";

export default function Tentang() {
  return (
    <>
      <PageHeader
        title="Tentang Kopineko"
        text="Kafe kecil yang dibuka karena kami butuh tempat ngopi yang tenang."
      />

      <section className="container py-5">
        <div className="row g-4 g-lg-5">
          <div className="col-12 col-lg-7">
            <p>
              Kopineko dibuka karena kami capek cari kafe yang enak tapi bikin
              kantong tipis. Kami mau tempat yang tenang, ada colokan di tiap
              meja, dan kopinya tetap terjangkau buat anak kuliah.
            </p>
            <p>
              &quot;Neko&quot; artinya kucing dalam bahasa Jepang. Kami pilih
              nama itu karena kucing simbol santai: duduk lama di satu tempat
              dan tidak buru-buru ke mana-mana.
            </p>
            <p>
              Sekarang tempat ini ramai oleh mahasiswa yang ngerjain tugas,
              pekerja remote, dan teman-teman yang ngobrol sampai malam.
            </p>
          </div>

          <div className="col-12 col-lg-5">
            <dl className="info-list">
              <InfoRow
                label="Visi"
                value="Jadi kafe yang nyaman dan terjangkau untuk semua orang."
              />
              <InfoRow
                label="Misi"
                value="Menyajikan kopi yang konsisten, menjaga suasana tetap tenang, dan melayani pengunjung dengan ramah."
              />
            </dl>
          </div>
        </div>
      </section>
    </>
  );
}
