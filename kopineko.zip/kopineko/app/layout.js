import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export const metadata = {
  title: "Kopineko - Kafe Nyaman untuk Ngopi Santai",
  description: "Company profile Kopineko, kafe dengan kopi, minuman, dan camilan favorit."
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className="d-flex flex-column min-vh-100">
        <Navbar />
        <main className="flex-grow-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
