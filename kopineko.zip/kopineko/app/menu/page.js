import { PageHeader } from "@/components/PageHeader";
import { Board } from "@/components/Board";
import { MenuRow } from "@/components/MenuRow";
import { menu, categories } from "@/data/menu";

export default function Menu() {
  return (
    <>
      <PageHeader
        title="Menu"
        text="Harga ditulis dalam ribuan, jadi 24K artinya Rp 24.000. Klik salah satu menu untuk lihat isinya."
      />

      <section className="container py-5">
        <Board>
          <div className="board-columns">
            {categories.map(function (category) {
              // Ambil menu yang kategorinya sama
              const items = menu.filter(function (item) {
                return item.category === category;
              });

              return (
                <div className="menu-group" key={category}>
                  <h2 className="menu-group-title">{category}</h2>
                  {items.map(function (item) {
                    return <MenuRow key={item.id} item={item} />;
                  })}
                </div>
              );
            })}
          </div>
        </Board>
      </section>
    </>
  );
}
