import Link from "next/link";
import { Board } from "@/components/Board";
import { findMenu, formatRupiah } from "@/lib/helper";

// Halaman detail, id diambil dari URL (/menu/americano)
export default async function DetailMenu({ params }) {
  const { id } = await params;
  const item = findMenu(id);

  // Kalau id tidak ada di data, tampilkan pesan saja
  if (!item) {
    return (
      <section className="container py-5">
        <h1 className="page-title">Menu tidak ditemukan</h1>
        <p>Menu ini tidak ada di daftar kami. Coba pilih dari halaman menu.</p>
        <Link href="/menu" className="btn btn-primary">
          Kembali ke menu
        </Link>
      </section>
    );
  }

  return (
    <section className="container py-5">
      <Link href="/menu">Kembali ke menu</Link>

      <div className="row g-4 g-lg-5 mt-0">
        <div className="col-12 col-md-5">
          <Board>
            <h1 className="board-name">{item.name}</h1>
            <p className="board-price">{formatRupiah(item.price)}</p>
            <p className="mb-0">
              {item.category}, {item.size}
            </p>
          </Board>
        </div>

        <div className="col-12 col-md-7">
          <p className="fs-5">{item.description}</p>

          <h2 className="h4">Isinya</h2>
          <ul>
            {item.ingredients.map(function (ingredient) {
              return <li key={ingredient}>{ingredient}</li>;
            })}
          </ul>

          <h2 className="h4">Kata barista</h2>
          <p>{item.note}</p>

          <Link href="/kontak" className="btn btn-primary">
            Cara pesan
          </Link>
        </div>
      </div>
    </section>
  );
}
