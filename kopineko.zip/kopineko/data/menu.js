// Kategori menu, urutannya dipakai di halaman Menu
export const categories = ["Kopi", "Non-Kopi", "Camilan"];

// Data menu Kopineko, dipakai di halaman Menu dan halaman detail
export const menu = [
  {
    id: "es-kopi-susu-neko",
    name: "Es Kopi Susu Neko",
    category: "Kopi",
    price: 24000,
    description: "Espresso, susu segar, dan gula aren.",
    ingredients: ["Espresso", "Susu segar", "Gula aren", "Es batu"],
    size: "350 ml",
    note: "Manisnya sedang. Kalau mau lebih tawar, bilang aja pas pesan."
  },
  {
    id: "americano",
    name: "Americano",
    category: "Kopi",
    price: 18000,
    description: "Espresso dengan air panas, ringan dan wangi.",
    ingredients: ["Espresso", "Air panas"],
    size: "250 ml",
    note: "Cocok buat yang suka kopi tanpa susu. Bisa dipesan panas atau dingin."
  },
  {
    id: "cappuccino",
    name: "Cappuccino",
    category: "Kopi",
    price: 26000,
    description: "Espresso, susu panas, dan foam yang tebal.",
    ingredients: ["Espresso", "Susu", "Milk foam"],
    size: "250 ml",
    note: "Foam-nya tebal, jadi paling enak diminum selagi masih hangat."
  },
  {
    id: "matcha-latte",
    name: "Matcha Latte",
    category: "Non-Kopi",
    price: 27000,
    description: "Matcha bubuk dengan susu, creamy dan tidak terlalu pahit.",
    ingredients: ["Bubuk matcha", "Susu", "Gula cair"],
    size: "300 ml",
    note: "Warnanya hijau pekat dan rasanya tidak terlalu manis."
  },
  {
    id: "butter-croissant",
    name: "Butter Croissant",
    category: "Camilan",
    price: 20000,
    description: "Croissant berlapis yang wangi mentega.",
    ingredients: ["Tepung", "Mentega", "Ragi"],
    size: "1 buah",
    note: "Selalu dihangatkan dulu sebelum disajikan."
  },
  {
    id: "roti-bakar-coklat",
    name: "Roti Bakar Coklat",
    category: "Camilan",
    price: 18000,
    description: "Roti tebal dibakar renyah, isi coklat leleh dan keju.",
    ingredients: ["Roti tawar", "Coklat", "Keju", "Mentega"],
    size: "1 porsi",
    note: "Porsinya cukup buat berdua kalau mau berbagi."
  }
];
