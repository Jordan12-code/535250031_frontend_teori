// Judul di bagian atas halaman dalam (Menu, Tentang, Kontak)
export function PageHeader({ title, text }) {
  return (
    <header className="band py-5">
      <div className="container">
        <h1 className="page-title">{title}</h1>
        {text && <p className="page-text mb-0">{text}</p>}
      </div>
    </header>
  );
}
