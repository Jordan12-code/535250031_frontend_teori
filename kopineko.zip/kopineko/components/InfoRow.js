// Satu baris info (label dan isinya), taruh di dalam <dl className="info-list">
export function InfoRow({ label, value }) {
  return (
    <div className="info-row">
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}
