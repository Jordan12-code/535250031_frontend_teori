// Papan tulis ala kafe, dipakai buat daftar menu dan detail menu
export function Board({ title, children }) {
  return (
    <div className="board">
      {title && <h2 className="board-title">{title}</h2>}
      {children}
    </div>
  );
}
