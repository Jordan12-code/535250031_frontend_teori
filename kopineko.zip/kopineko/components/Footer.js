export function Footer() {
  return (
    <footer className="site-footer py-4">
      <div className="container d-flex flex-column flex-md-row justify-content-between gap-2">
        <p className="mb-0">&copy; 2026 Kopineko</p>
        <p className="mb-0">
          Jl. Kucing Manis No. 8, buka tiap hari 09.00 sampai 22.00 WIB
        </p>
      </div>
    </footer>
  );
}
