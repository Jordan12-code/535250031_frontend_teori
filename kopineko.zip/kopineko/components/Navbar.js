"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const navLinks = [
  { href: "/", label: "Beranda" },
  { href: "/menu", label: "Menu" },
  { href: "/tentang", label: "Tentang" },
  { href: "/kontak", label: "Kontak" }
];

export function Navbar() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);

  // Cek link yang lagi aktif, /menu/americano tetap dianggap aktif di menu Menu
  function isActive(href) {
    if (href === "/") {
      return pathname === "/";
    }
    return pathname.startsWith(href);
  }

  let collapseClass = "collapse navbar-collapse";
  if (isOpen) {
    collapseClass = "collapse navbar-collapse show";
  }

  return (
    <nav className="site-nav navbar navbar-expand-md sticky-top">
      <div className="container">
        <Link
          href="/"
          className="navbar-brand"
          onClick={function () {
            setIsOpen(false);
          }}
        >
          {/* Logo kucing sederhana */}
          <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true">
            <path
              d="M4 3 L12 9 H20 L28 3 V19 Q28 29 16 29 Q4 29 4 19 Z"
              fill="#2E3B47"
            />
            <circle cx="12" cy="18" r="2" fill="#F4D56B" />
            <circle cx="20" cy="18" r="2" fill="#F4D56B" />
          </svg>
          Kopineko
        </Link>

        <button
          type="button"
          className="navbar-toggler"
          aria-controls="nav-menu"
          aria-expanded={isOpen}
          aria-label="Buka navigasi"
          onClick={function () {
            setIsOpen(!isOpen);
          }}
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className={collapseClass} id="nav-menu">
          <ul className="navbar-nav ms-auto">
            {navLinks.map(function (link) {
              let linkClass = "nav-link";
              let current = undefined;
              if (isActive(link.href)) {
                linkClass = "nav-link active";
                current = "page";
              }

              return (
                <li className="nav-item" key={link.href}>
                  <Link
                    href={link.href}
                    className={linkClass}
                    aria-current={current}
                    onClick={function () {
                      setIsOpen(false);
                    }}
                  >
                    {link.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </nav>
  );
}
