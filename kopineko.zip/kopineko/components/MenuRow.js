import Link from "next/link";
import { shortPrice } from "@/lib/helper";

// Satu baris menu di papan: nama, titik-titik, harga, lalu deskripsi
export function MenuRow({ item }) {
  return (
    <Link href={"/menu/" + item.id} className="menu-row">
      <span className="menu-row-name">{item.name}</span>
      <span className="menu-row-dots"></span>
      <span className="menu-row-price">{shortPrice(item.price)}</span>
      <span className="menu-row-desc">{item.description}</span>
    </Link>
  );
}
